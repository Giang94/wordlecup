package com.app.wordlecup.single.model;

import java.util.List;

public record RecentGameResp(
        List<String> recentGames,
        int streak
) {
}