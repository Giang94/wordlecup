package com.app.wordlecup.single.model;

public record GuessRequest(String gameId, String guess) {}